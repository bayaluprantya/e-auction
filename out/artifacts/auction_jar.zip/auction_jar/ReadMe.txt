src => java source folders which fulfill the functionality detailed in Auction_Code_sample_java.rtf
doc => contain generated javadoc for the source files
lib => required junit libraries
auction.jar => compiled classes from src folder